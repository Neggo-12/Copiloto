---
name: "pre-build-plan"
description: "Usar cuando el usuario solicite una refactorización masiva, lógica de negocio compleja o cambios que afecten a más de dos archivos simultáneamente, antes de proceder a la escritura de código."
---

Protocolo de análisis previo (Ahorro de créditos):

1. Detén cualquier intento automático de escritura o modificación de archivos masiva. Alértame en modo "Plan Mode".
2. Utiliza los subagentes de lectura incorporados para inspeccionar el estado actual de los archivos involucrados sin alterarlos.
3. Preséntame un mapa conceptual del cambio que incluya de forma explícita:
  - Qué archivos específicos serán editados.
  - Qué funciones o variables se añadirán o alterarán.
  - Qué riesgos potenciales de romper tipos de TypeScript o dependencias existen.
4. Espera mi aprobación explícita textualmente antes de ejecutar el código en "Build Mode".

Resultado esperado: Un plan detallado de cambios que previene ciclos infinitos de reparación de bugs y optimiza el uso de la infraestructura.