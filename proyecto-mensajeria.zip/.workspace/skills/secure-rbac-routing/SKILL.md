---
name: "secure-rbac-routing"
description: "Usar cuando se creen o modifiquen rutas del App Router de Next.js 15, endpoints de la API (/api/) o componentes de navegación, asegurando la segregación estricta de accesos por rol."
---

Restricciones y reglas de seguridad de código:

1. Respeta estrictamente los tres entornos del sistema mediante el enum UserRole: 'OFICIAL_FIDUCIARIA', 'CONSTRUCTOR_DIRECTOR' e 'INTERVENTOR_EXTERNO'.
2. Cada vez que generes una página interna bajo '/dashboard', verifica que esté mapeada correctamente en la matriz de configuración de 'src/config/routes.ts'.
3. No utilices validaciones de sesión del lado del cliente para proteger páginas críticas. El acceso debe ser controlado a nivel de servidor por 'src/middleware.ts'.
4. En Server Components, extrae los metadatos de identidad leyendo directamente los headers síncronos inyectados downstream ('x-fidu-user-id', 'x-fidu-user-role', 'x-fidu-user-nit').
5. Toda cookie de autenticación debe configurarse con las banderas: httpOnly: true, secure: true, sameSite: 'strict', y llevar el prefijo '__Host-'.

Resultado esperado: Código blindado a nivel de infraestructura que impide a un rol acceder a datos o componentes de otro entorno.