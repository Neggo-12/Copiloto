---
name: "premium-ui-design"
description: "Usar cuando el usuario solicite crear, rediseñar o modificar una pantalla, vista de dashboard o componente de interfaz, limitándose estrictamente al frontend estético sin alterar la lógica compleja del backend."
---

Pasos obligatorios para la generación de interfaces:

1. Aplica un enfoque ultra-minimalista inspirado en Stripe y Mercury. Quedan prohibidos los gradientes multicolores, las ilustraciones ruidosas y las sombras pesadas.
2. Usa una retícula estricta de bordes de 1px ('border-slate-200/60' para modo claro o 'border-zinc-800/80' para modo oscuro) como método principal de separación de elementos en lugar de elevación por sombras.
3. Aplica compresión tipográfica editorial a los encabezados (H1, H2, H3) usando 'tracking-tight' o '-0.02em'.
4. Todos los datos numéricos, porcentajes, montos financieros o códigos deben renderizarse obligatoriamente con fuentes monoespaciadas ('font-mono') para asegurar alineación geométrica.
5. Utiliza componentes base de shadcn/ui instalados en 'src/components/ui/' y extiéndelos usando únicamente clases de Tailwind CSS nativas.

Resultado esperado: Una interfaz limpia, de alta densidad de datos, sobria y profesional que transmita seguridad bancaria.