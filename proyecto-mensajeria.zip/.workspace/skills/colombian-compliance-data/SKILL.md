---
name: "colombian-compliance-data"
description: "Usar cuando se definan esquemas de validación (Zod), modelos de bases de datos o formularios de captura para registrar transacciones, hitos constructivos o datos empresariales en Colombia"
---

Reglas de negocio y consistencia de datos:

1. El campo para identificación de empresas debe tiparse estrictamente como 'nitEmpresa' y soportar el formato estándar colombiano con dígito de verificación (ej. 901.456.789-0).
2. Los usuarios con el rol 'INTERVENTOR_EXTERNO' deben incluir de forma obligatoria el metadato 'tarjetaProfesional' validado en string no vacío.
3. Toda tabla de auditoría, registro fotográfico o aprobación de hito debe almacenar de forma inalterable: 'timestamp' (ISO string del servidor), 'geolocalizacion' (coordenadas lat/lng precisas) y una marca de agua digital asociada al ID del firmante.
4. Las facturas cargadas al sistema deben prever campos de vinculación con los estándares de la DIAN (CUFE - Código Único de Factura Electrónica).

Resultado esperado: Esquemas de TypeScript y Zod técnicamente precisos que evitan la inserción de datos basura o vacíos legales ante auditorías del Decreto 510 de 2026.