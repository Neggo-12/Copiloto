Aplica las siguientes reglas estrictas, convenciones de nomenclatura, patrones de arquitectura y preferencias estéticas a todos los proyectos de este espacio de trabajo:

1. STACK TECNOLÓGICO OBLIGATORIO Y ARQUITECTURA
- Framework: TanStack Start (Estructura full-stack basada en Vite, utilizando TanStack Router para el enrutamiento estrictamente tipado basado en archivos bajo 'src/routes/').
- Lenguaje: TypeScript estricto (prohibido el uso de 'any', tipado obligatorio en Loaders, Actions, componentes y estados).
- Estilos: Tailwind CSS (clases nativas y limpias).
- Componentes UI: Primitivos modulares de shadcn/ui instalados en 'src/components/ui/' y adaptados nativamente a TanStack.
- Estado Global: Zustand o estado nativo de TanStack para persistencia ligera en el cliente.
- Conectividad y Caché: TanStack Query (React Query) integrado nativamente con los Loaders de las rutas para la gestión eficiente de datos asíncronos.
- Backend/Base de Datos: Supabase / PostgreSQL integrado mediante Server Functions seguras.

2. ESTÉTICA Y CONVENCIONES DE DISEÑO (Fintech Premium - Estilo Stripe / Mercury)
- Enfoque visual: Ultra-minimalista, geométrico, sobrio y de alta densidad de información. Quedan prohibidos los gradientes ruidosos, las sombras pesadas, los iconos infantiles y las ilustraciones genéricas tridimensionales.
- Elevación: Los contenedores y tarjetas se separan mediante bordes fijos de 1px con opacidades sutiles ('border-slate-200/60' para modo claro o 'border-zinc-800/80' para modo oscuro), reemplazando la elevación tradicional por sombras flotantes.
- Paleta de Colores: Superficies limpias usando Off-white (#F9FAFB) o Blanco Puro (#FFFFFF) para superficies elevadas en modo claro. Gris pizarra profundo (#0B0F19) o Zinc profundo para entornos oscuros de alta seguridad. El único color de acento permitido es Verde Esmeralda Técnico (#10B981) para estados validados, botones primarios y KPIs óptimos.
- Tipografía y Ajuste Óptico: Estilo sans-serif limpio (Inter o SF Pro). Títulos con compresión de tracking editorial ('tracking-tight' o '-0.02em'). Datos numéricos, montos financieros, fechas y porcentajes formateados obligatoriamente con fuente monoespaciada ('font-mono') para garantizar alineación geométrica exacta.

3. CONTEXTO DE NEGOCIO Y REGLAS DE SEGURIDAD (Colombia - Zero-Trust)
- Propósito: Plataforma B2B diseñada para mitigar el fraude de "jineteo de fondos" en la construcción civil y asegurar el estricto cumplimiento del Decreto 510 de 2026 de la Superintendencia Financiera de Colombia para proyectos multifamiliares.
- Sistema RBAC (Control de Accesos Basado en Roles): Existen tres entornos y roles inmutables:
  * 'OFICIAL_FIDUCIARIA': Control de riesgos, semáforos financieros, auditoría forense e indicador IDH (Índice de Desviación de Hito).
  * 'CONSTRUCTOR_DIRECTOR': Configuración de la Matriz de Átomos (WBS/EDT), cargas de facturas electrónicas con validación de la DIAN y solicitudes de desembolso atadas a hitos físicos.
  * 'INTERVENTOR_EXTERNO': Validación técnica en campo con captura fotográfica geolocalizada y firma criptográfica de la tercera llave para liberación de fondos.
- Seguridad de Sesión: Toda sesión y token criptográfico (JWT) debe manejarse mediante cookies seguras que implementen obligatoriamente el prefijo '__Host-' y las políticas 'httpOnly: true', 'secure: true' y 'sameSite: 'strict''. El rol y la autenticación se validan de forma síncrona a nivel de servidor utilizando los Loaders de TanStack Router o Server Functions antes de resolver la ruta o descargar cualquier byte de información protegida en el cliente.

4. COMPORTAMIENTO DE CODIFICACIÓN
- Generar código modular, componentes altamente reutilizables en la carpeta 'src/components/shared', layouts limpios y código auto-explicativo con comentarios estrictamente técnicos. 
- Priorizar el rendimiento utilizando Server Functions para consultas pesadas y reduciendo la interactividad innecesaria en el cliente.